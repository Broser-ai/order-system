# 📦 Multi-Brand Order System

Bestillingssystem til Apple, JBL og Marshall produkter med:
- 5 sprog (DA/EN/DE/HI/ZH)
- 5 valutaer (DKK/EUR/USD/INR/CNY)
- Proforma faktura + Indkøbsordre
- Excel-eksport
- Email-integration
- Global søgning

## Deploy på Vercel

1. Push dette repo til GitHub
2. Gå til [vercel.com/new](https://vercel.com/new)
3. Importér dit GitHub repo
4. Klik "Deploy"
5. Færdig!
